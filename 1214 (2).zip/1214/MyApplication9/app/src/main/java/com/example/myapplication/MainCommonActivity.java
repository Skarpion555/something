package com.example.myapplication;

import static android.widget.Button.*;
import static kotlin.random.RandomKt.Random;

import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Scanner;


public class MainCommonActivity extends AppCompatActivity implements View.OnClickListener {

    Button Button1;
    Button Button2;
    Button Button3;
    Button Button4;
    Button Button5;
    String selected_answer = "";
    int Score = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_common);

        Button1 = findViewById(R.id.firstlne);
        Button2 = findViewById(R.id.secondlne);
        Button3 = findViewById(R.id.thirdlne);
        Button4 = findViewById(R.id.fourthlne);
        Button5 = findViewById(R.id.fifthlne);

        Button1.setOnClickListener(this);
        Button2.setOnClickListener(this);
        Button3.setOnClickListener(this);
        Button4.setOnClickListener(this);
        Button5.setOnClickListener(this);
        loadQuestion();

    }

    @Override
    public void onClick(View v) {
        Button button = (Button) v;
        Score++;
        selected_answer =button.getText().toString();
        button.setBackgroundColor(Color.rgb(158, 142, 0));
        button.setText(Datan.WordEng[(int) Math.round((Datan.WordEng.length)*(Math.random()))]);

    }

    private void loadQuestion() {

        Button1.setText(Datan.WordEng[(int) Math.round((Datan.WordEng.length)*(Math.random()))]);
        Button2.setText(Datan.WordEng[(int) Math.round((Datan.WordEng.length)*(Math.random()))]);
        Button3.setText(Datan.WordEng[(int) Math.round((Datan.WordEng.length)*(Math.random()))]);
        Button4.setText(Datan.WordEng[(int) Math.round((Datan.WordEng.length)*(Math.random()))]);
        Button5.setText(Datan.WordEng[(int) Math.round((Datan.WordEng.length)*(Math.random()))]);


    }
    public void timerEnd(){

    }
}