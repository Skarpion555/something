package com.example.myapplication;

import static android.widget.Button.*;
import static kotlin.random.RandomKt.Random;

import androidx.appcompat.app.AppCompatActivity;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.Arrays;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Scanner;


public class MainCommonActivity extends AppCompatActivity implements View.OnClickListener {

    TextView timer;
    TextView raund1;
    TextView name;
    TextView sec;
    int time = 11;
    Button Button1;
    Button Button2;
    Button Button3;
    Button Button4;
    Button Button5;
    int Score = 0;
    int Tiv = 4;
    String[] result;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_common);
        timer = findViewById(R.id.timer);
        sec = findViewById(R.id.secleft);
        raund1 = findViewById(R.id.raund);
        name = findViewById(R.id.teamsname);
        raund1.setText(String.valueOf(Datan.raund));
        if(Datan.team1) {
            name.setText(String.valueOf(Datan.teamcom1));
        }else{
            name.setText(String.valueOf(Datan.teamcom2));
        }
        switch (Datan.result) {
            case 0:
                result = shuffleString(Datan.WordAlias);
                break;
            case 1:
                result = shuffleString(Datan.WordsailA);
                break;
            case 2:
                result = shuffleString(Datan.WordYes);
                break;
            case 3:
                result = shuffleString(Datan.WordNO);
                break;
        }


        Button1 = findViewById(R.id.firstlne);
        Button2 = findViewById(R.id.secondlne);
        Button3 = findViewById(R.id.thirdlne);
        Button4 = findViewById(R.id.fourthlne);
        Button5 = findViewById(R.id.fifthlne);

        Button1.setOnClickListener(this);
        Button2.setOnClickListener(this);
        Button3.setOnClickListener(this);
        Button4.setOnClickListener(this);
        Button5.setOnClickListener(this);
        loadQuestion();
        Handler handler = new Handler();

        Runnable runnable = new Runnable() {
                    public void run() {
                        --time;
                        if (time<0){
                            time++;
                            timer.setTextColor(Color.rgb(255, 0, 0));
                            sec.setTextColor(Color.rgb(255, 0, 0));

                        }
                        timer.setText(String.valueOf(time));
                        Log.i("Interval",String.valueOf(time));
                        handler.postDelayed(this,1000);
                    }
                };
        handler.post(runnable);
    }
    @Override
    public void onClick(View v) {
        Button button = (Button) v;
        if(time <= 0){
            timerEnd();
        }else {
            Tiv++;
            Handler handler = new Handler();
            Runnable runnable1 = new Runnable() {
                public void run() {
                    button.setBackgroundColor(getColor(R.color.transparent));
                }
            };
            if (Tiv == result.length) {
                Tiv--;
                button.setBackgroundColor(Color.rgb(158, 142, 0));
            } else {
                button.setBackgroundColor(Color.rgb(158, 142, 0));
                button.setText(result[Tiv]);
                Score++;
                handler.postDelayed(runnable1, 600);
            }
        }

    }
    private void loadQuestion() {
        Button1.setText(result[0]);
        Button2.setText(result[1]);
        Button3.setText(result[2]);
        Button4.setText(result[3]);
        Button5.setText(result[4]);
    }
    public void timerEnd(){
        if(Datan.team1){
            Datan.teamcomscore1 += Score;
        }else{
            Datan.teamcomscore2 += Score;
        }
        Datan.team1 = !Datan.team1;
        Intent intent = new Intent(getApplicationContext(), CommonScoreActivity.class);
        startActivity(intent);
    }
    public static String[]  shuffleString(String[] arr) {
        String[] randomizedArray = new String[arr.length];
        System.arraycopy(arr, 0, randomizedArray, 0, arr.length);
        Random rgen = new Random();
        for (int i = 0; i < randomizedArray.length; i++) {
            int randPos = rgen.nextInt(randomizedArray.length);
            String tmp = randomizedArray[i];
            randomizedArray[i] = randomizedArray[randPos];
            randomizedArray[randPos] = tmp;
        }
        return randomizedArray;
    }
}