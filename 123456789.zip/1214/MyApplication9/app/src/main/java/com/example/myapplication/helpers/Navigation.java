package com.example.myapplication.helpers;

import static androidx.core.content.ContextCompat.startActivity;

import android.content.Context;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication.MainActivity;

public class Navigation {

}
