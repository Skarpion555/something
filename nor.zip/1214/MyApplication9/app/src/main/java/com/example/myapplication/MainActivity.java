package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    TextView top1;
    TextView top2;
    TextView top3;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        top1 = findViewById(R.id.top1surviver);
        top2 = findViewById(R.id.top2surviver);
        top3 = findViewById(R.id.top3surviver);
        top1.setText(Datan.topteam1name);
        top2.setText(Datan.topteam2name);
        top3.setText(Datan.topteam3name);
        Datan.teamcom1 = "";
        Datan.teamcom2 = "";
        Datan.teamsurv = "";
        Datan.raund = 0;
        Datan.teamcomscore1 = 0;
        Datan.teamcomscore2 = 0;
        Datan.teamsurvscore = 0;
        Datan.common = false;
        Datan.team1 = true;
        Datan.team1win = false;
        Datan.team2win = false;
    }

    public void MainSurvivalBtn(View v){
       Intent intent = new Intent(this, SurvivalregisterActivity.class);
       startActivity(intent);
    }
    public void MainCommonBtn(View v){
        Datan.common = true;
        Intent intent = new Intent(this, Commonregister.class);
        startActivity(intent);
    }
}