package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;

public class RandomiserActivity extends AppCompatActivity {
    double end = 3+(3*Math.random());

    double start = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_randomiser);
    }
    public void CommonRandomise(View v) {
        ImageView image = findViewById(R.id.image);
        if(Datan.common) {
            if (Datan.team1){
            Datan.raund++;
            }
        }else{
            Datan.raund++;
        }
        Handler handler = new Handler();
        Runnable runnable2 = new Runnable() {
            public void run() {
                    image.setImageResource(Datan.image[(int) (start % Datan.image.length)]);
                    handler.postDelayed(this, 300);
                    start++;
            }
        };
        handler.post(runnable2);
        Runnable runnable3 = new Runnable() {
            public void run() {
                    handler.postDelayed(this, 4000);
                }
        };
        handler.post(runnable3);
        Intent intent = new Intent(this, MainCommonActivity.class);
        startActivity(intent);
    }
}