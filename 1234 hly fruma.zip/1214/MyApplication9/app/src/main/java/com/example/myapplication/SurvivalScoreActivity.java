package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class SurvivalScoreActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_survival_score);
    }
    public void SurvivalContinue(View v){
        Intent intent = new Intent(this, SurvivialRandomiserActivity.class);
        startActivity(intent);
    }

}