package com.example.myapplication;

import com.google.firebase.firestore.FirebaseFirestore;

public class Datan {

   public static FirebaseFirestore db = FirebaseFirestore.getInstance();

   public static String WordAlias[] = {
           "contain", "horn", "handsomely", "abandoned", "pastoral",
           "somber", "shivering", "complete", "vegetable", "trust",
           "soggy", "billowy", "maniacal", "government", "fixed",
           "unused", "bite", "ask", "interfere", "appliance",
           "finicky", "believe", "whimsical", "mother", "grieving",
           "punch", "ill", "nut", "rule", "sink", "owe", "ray",
           "design", "toes", "wrestle", "reject", "phobic",
           "ultra", "demonic", "spiteful", "versed", "well-to-do",
           "aware", "curious", "hilarious", "multiply", "teeny-tiny",
           "heal", "year", "wax", "simple", "wheel", "powder", "baby",
           "produce", "elastic", "unique", "knee", "forgetful", "miss",
           "blush", "unnatural", "oranges", "ubiquitous", "yak",
           "governor", "telephone", "country", "horrible", "tooth",
           "far-flung", "dime", "price", "field", "chess",
           "envious", "butter", "bawdy", "jumpy", "protest", "kill",
           "military", "robust", "prefer", "scorch", "learned",
           "rightful", "tin", "plane", "magic", "allow", "eager",
           "zany", "sponge", "material", "freezing", "north",
           "watery", "substantial", "stitch", "share",
   };
   public static String WordsailA[] = {
           "ekahs", "xis", "detacifitsophs", "level", "pmot",
           "sllod", "sselhtur", "klim", "tnemeyap", "wef",
           "elbissop", "gnikartraeb", "esiar", "pmub", "deniabma",
           "citsalp", "pohs", "doog", "thgin", "yks", "gnuoy", "lwarC",
           "ylug", "gnikats", "niamer", "dnuorgyalp", "trap", "tnaw",
           "ylf", "ylidaeg", "tar", "kcab", "erutaerc", "gnitaesanua",
           "yart", "lavo", "tops", "geba", "ragus", "tnarfalg", "tsoab",
           "evitcudorp", "enadnum", "gnivird", "ados", "tnulucurt",
           "suoiralih", "rettel", "ladep", "htrae", "txen", "demraun",
           "thgiled", "kool", "tneuqnocna", "ketram", "cikarfan",
           "krow", "deb", "elbavegev", "pmal", "sserpmi", "rettib",
           "ymoaf", "referp", "mrofrepmoc", "niartuc", "truh",
           "yramuh", "retefulf", "kcir", "tnoehtfire", "tnegev",
           "detnaw", "peek", "rowyd", "nrael", "lossaloc",
           "tneserp", "elttil", "reppad", "tuorger", "nruom",
           "hsarb", "eciffo"
   };
   public static String WordYes[] = {
           "cheap(thrifty)", "spend(thrifty)", "money(thrifty)", "stingy(thrifty)",
           "twice(double)", "number(double)", "triple(double)", "amount(double)",
           "terrible(tragedy)", "sad(tragedy)", "victim(tragedy)", "disaster(tragedy)",
           "grass(lawn)", "mow(lawn)", "green(lawn)", "yard(lawn)",
           "jail(arrest)", "criminal(arrest)", "police(arrest)", "handcuffs(arrest)",
           "child(educate)", "teach(educate)", "learn(educate)", "school(educate)",
           "Greek(myth)", "legend(myth)", "history(myth)", "culture(myth)",
           "unit(measurement)", "height(measurement)", "distance(measurement)", "length(measurement)",
           "doctor(prescription)", "paper(prescription)", "medicine(prescription)", "pharmacy(prescription)",
           "bury(grave)", "cemetery(grave)", "dig(grave)", "funeral(grave)",
           "women(makeup)", "lipstick(makeup)", "pretty(makeup)", "put on(makeup)",
           "deer(hunt)", "gun(hunt)", "woods(hunt)", "food(hunt)",
           "doctor(surgeon)", "surgery(surgeon)", "operation(surgeon)", "hospital(surgeon)",
           "city(suburb)", "outside(suburb)", "quiet(suburb)", "live(suburb)",
           "maximum(minimum)", "lowest(minimum)", "wage(minimum)", "amount(minimum)",
           "holy(sacred)", "religious(sacred)", "blessed(sacred)", "cow(sacred)",
           "soldier(warrior)", "war(warrior)", "attack(warrior)", "battle(warrior)",
           "work(retired)", "relax(retired)", "old(retired)", "pension(retired)",
           "ask(survey)", "questions(survey)", "opinion(survey)", "fill out(survey)",
           "politician(corruption)", "bribe(corruption)", "government(corruption)", "scandal(corruption)",
           "fishing(hook)", "metal(hook)", "sharp(hook)", "bait(hook)",
           "sprain(ankle)", "leg(ankle)", "foot(ankle)", "break(ankle)",
           "climb(steep)", "mountain(steep)", "hill(steep)", "angle(steep)",
           "disease(spread)", "virus(spread)", "infection(spread)", "prevent(spread)",
           "together(cooperate)", "everyone(cooperate)", "unite(cooperate)", "work(cooperate)",
           "human(sacrifice)", "kill(sacrifice)", "ritual(sacrifice)", "blood(sacrifice)",
           "gum(bubble)", "soap(bubble)", "blow(bubble)", "pop(bubble)"
   };
   public static String WordNO[] = {
           "cheap(thrifty)", "spend(thrifty)", "money(thrifty)", "stingy(thrifty)",
           "twice(double)", "number(double)", "triple(double)", "amount(double)",
           "terrible(tragedy)", "sad(tragedy)", "victim(tragedy)", "disaster(tragedy)",
           "grass(lawn)", "mow(lawn)", "green(lawn)", "yard(lawn)",
           "jail(arrest)", "criminal(arrest)", "police(arrest)", "handcuffs(arrest)",
           "child(educate)", "teach(educate)", "learn(educate)", "school(educate)",
           "Greek(myth)", "legend(myth)", "history(myth)", "culture(myth)",
           "unit(measurement)", "height(measurement)", "distance(measurement)", "length(measurement)",
           "doctor(prescription)", "paper(prescription)", "medicine(prescription)", "pharmacy(prescription)",
           "bury(grave)", "cemetery(grave)", "dig(grave)", "funeral(grave)",
           "women(makeup)", "lipstick(makeup)", "pretty(makeup)", "put on(makeup)",
           "deer(hunt)", "gun(hunt)", "woods(hunt)", "food(hunt)",
           "doctor(surgeon)", "surgery(surgeon)", "operation(surgeon)", "hospital(surgeon)",
           "city(suburb)", "outside(suburb)", "quiet(suburb)", "live(suburb)",
           "maximum(minimum)", "lowest(minimum)", "wage(minimum)", "amount(minimum)",
           "holy(sacred)", "religious(sacred)", "blessed(sacred)", "cow(sacred)",
           "soldier(warrior)", "war(warrior)", "attack(warrior)", "battle(warrior)",
           "work(retired)", "relax(retired)", "old(retired)", "pension(retired)",
           "ask(survey)", "questions(survey)", "opinion(survey)", "fill out(survey)",
           "politician(corruption)", "bribe(corruption)", "government(corruption)", "scandal(corruption)",
           "fishing(hook)", "metal(hook)", "sharp(hook)", "bait(hook)",
           "sprain(ankle)", "leg(ankle)", "foot(ankle)", "break(ankle)",
           "climb(steep)", "mountain(steep)", "hill(steep)", "angle(steep)",
           "disease(spread)", "virus(spread)", "infection(spread)", "prevent(spread)",
           "together(cooperate)", "everyone(cooperate)", "unite(cooperate)", "work(cooperate)",
           "human(sacrifice)", "kill(sacrifice)", "ritual(sacrifice)", "blood(sacrifice)",
           "gum(bubble)", "soap(bubble)", "blow(bubble)", "pop(bubble)"
   };
   public static int image[] = {
           R.drawable.alias,
           R.drawable.saila,
           R.drawable.yes,
           R.drawable.nonoise
   };
   public static String game[] = {
           "Alias",
           "sailA",
           "Yes/No",
           "NoNoise"
   };
   public static String teamcom1 = "";
   public static String teamcom2 = "";
   public static String teamsurv = "";
   public static int raund = 0;
   public static int result;
   public static int Scoreend;
   public static int teamcomscore1 = 0;
   public static int teamcomscore2 = 0;
   public static int teamsurvscore = 0;
   public static int teamraundscore = 4;
   public static boolean common = false;
   public static boolean team1 = true;
   public static boolean team1win = false;
   public static boolean team2win = false;


   public static String topteam1name;
   public static String topteam2name;
   public static String topteam3name;
   public static int topteam1scr;
   public static int topteam2scr;
   public static int topteam3scr;

   public static void setTopteam1scr(int topteam1scr) {
      Datan.topteam1scr = topteam1scr;
      db.collection("DatanFire").document("38GY3Y4lIxxb4115mb41").update("topscr1",topteam1scr);
   }

   public static void setTopteam2scr(int topteam2scr) {
      Datan.topteam2scr = topteam2scr;
      db.collection("DatanFire").document("38GY3Y4lIxxb4115mb41").update("topscr2",topteam2scr);

   }

   public static void setTopteam3scr(int topteam3scr) {
      Datan.topteam3scr = topteam3scr;
      db.collection("DatanFire").document("38GY3Y4lIxxb4115mb41").update("topscr3",topteam3scr);

   }

   public static void setTopteam1name(String topteam1name) {
      Datan.topteam1name = topteam1name;
      db.collection("DatanFire").document("38GY3Y4lIxxb4115mb41").update("topname1",topteam1name);

   }

   public static void setTopteam2name(String topteam2name) {
      Datan.topteam2name = topteam2name;
      db.collection("DatanFire").document("38GY3Y4lIxxb4115mb41").update("topname2",topteam2name);
   }

   public static void setTopteam3name(String topteam3name) {
      Datan.topteam3name = topteam3name;
      db.collection("DatanFire").document("38GY3Y4lIxxb4115mb41").update("topname3",topteam3name);
   }
}
