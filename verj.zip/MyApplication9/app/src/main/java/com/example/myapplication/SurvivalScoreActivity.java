package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class SurvivalScoreActivity extends AppCompatActivity {
    Button button1;
    Button cont;
    ImageView imageView;
    boolean end = false;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_survival_score);
        imageView = findViewById(R.id.imageview);
        cont = findViewById(R.id.continue23);
        button1 = findViewById(R.id.firstscore);
        button1.setText("Team " + Datan.teamsurv + "'s score " + Datan.teamsurvscore);
    }
    public void SurvivalContinue(View v){
        if(!end) {
            if (Datan.teamraundscore < 4) {
                end = true;
                cont.setHintTextColor(getResources().getColor(R.color.purple));
                if(Datan.raund >= 1) {
                    if(Datan.raund+10 > Datan.topteam1scr){
                        Datan.setTopteam3scr(Datan.topteam2scr);
                        Datan.setTopteam3name(Datan.topteam2name);
                        Datan.setTopteam2scr(Datan.topteam1scr);
                        Datan.setTopteam2name(Datan.topteam1name);
                        Datan.setTopteam1scr(Datan.raund);
                        Datan.setTopteam1name(Datan.teamsurv);
                        cont.setText(Datan.teamsurv + " is Top1 (best ending)");
                        imageView.setImageResource(R.drawable.soccred);
                    }else if(Datan.raund > Datan.topteam2scr){
                        Datan.setTopteam3scr(Datan.topteam2scr);
                        Datan.setTopteam3name(Datan.topteam2name);
                        Datan.setTopteam2scr(Datan.raund);
                        Datan.setTopteam2name(Datan.teamsurv);
                        cont.setText(Datan.teamsurv + " is Top2 (very good ending)");
                        imageView.setImageResource(R.drawable.soccred);
                    }else if(Datan.raund > Datan.topteam3scr){
                        Datan.setTopteam3scr(Datan.raund);
                        Datan.setTopteam3name(Datan.teamsurv);
                        cont.setText(Datan.teamsurv + " is Top3 (good ending)");
                        imageView.setImageResource(R.drawable.soccred);
                    }else{
                    cont.setText(Datan.teamsurv + "'ve lost (bad ending)");
                    imageView.setImageResource(R.drawable.soclost);
                    }
                }else{
                    cont.setText(Datan.teamsurv + "'ve lost (bad ending)");
                    imageView.setImageResource(R.drawable.soclost);
                }
            }else{
                Intent intent = new Intent(this, RandomiserActivity.class);
                startActivity(intent);
            }
        }else{
            Intent intent1 = new Intent(this, MainActivity.class);
            startActivity(intent1);
        }
    }

}