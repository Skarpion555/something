package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void MainSurvivalBtn(View v){
       Intent intent = new Intent(this, SurvivalregisterActivity.class);
       startActivity(intent);
    }
    public void MainCommonBtn(View v){
        Intent intent = new Intent(this, Commonregister.class);
        startActivity(intent);
    }
}