package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.ImageView;

public class RandomiserActivity extends AppCompatActivity {
    int start = 0;
    double end = 3+(3*Math.random());


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_randomiser);
    }
    public void CommonRandomise(View v) {
        ImageView image = findViewById(R.id.image);
        Handler handler = new Handler();
        Runnable runnable2 = new Runnable() {
            public void run() {
                    image.setImageResource(Datan.image[(start) % Datan.image.length]);
                    handler.postDelayed(this, 300);
                    start++;
            }
        };
        handler.post(runnable2);

        Intent intent = new Intent(this, MainCommonActivity.class);
        startActivity(intent);
    }
}