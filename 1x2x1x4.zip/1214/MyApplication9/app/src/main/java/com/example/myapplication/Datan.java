package com.example.myapplication;

public class Datan {

   public static String WordEng[] = {
           "something1", "something2", "something3", "something4", "something5",
           "something6", "something7", "something8", "something9", "something10",
   };


}
