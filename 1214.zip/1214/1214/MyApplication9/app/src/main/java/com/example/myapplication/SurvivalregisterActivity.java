package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

public class SurvivalregisterActivity extends AppCompatActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.survivalregister);
    }
    public void SurvivalregistercanselBtn(View v){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
    public void SurvivalregisterloginBtn(View v){
        EditText edit_text = (EditText)findViewById(R.id.editText);
        String edittext =  edit_text.getText().toString();
        Intent intent = new Intent(this, SurvivalregisterActivity.class);
        startActivity(intent);
    }
}