package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class Commonregister extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_commonregister);
    }

    public void CommonregistercanselBtn(View v){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
    public void CommonregisterloginBtn(View v){
        EditText edit_text1 = (EditText)findViewById(R.id.editText1);
        EditText edit_text2 = (EditText)findViewById(R.id.editText2);
        String edittext1 =  edit_text1.getText().toString();
        String edittext2 =  edit_text2.getText().toString();
        Intent intent = new Intent(this, Commonregister.class);
        startActivity(intent);
    }
}