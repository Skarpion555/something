package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.TextView;
import java.util.Timer;
import java.util.TimerTask;
import android.app.Activity;
import android.os.Bundle;
import android.os.Message;
import android.os.Handler.Callback;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;



public class MainCommonActivity extends AppCompatActivity {
    Timer timer = new Timer();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_common);

        final TextView sec = findViewById(R.id.timer);
        final Handler h = new Handler(new Callback() {

            @Override
            public boolean handleMessage(Message msg) {
                int starttime = 60;
                long millis = System.currentTimeMillis() - starttime;
                int seconds = (int) (60-(millis / 1000));
                sec.setText(seconds);
                return false;
            }
        });


    }
}