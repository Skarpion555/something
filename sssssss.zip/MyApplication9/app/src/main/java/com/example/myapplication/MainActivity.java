package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.myapplication.dataclasses.DataClasses;
import com.google.firebase.firestore.FirebaseFirestore;

public class MainActivity extends AppCompatActivity {
    TextView top1;
    TextView top2;
    TextView top3;
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        top1 = findViewById(R.id.top1surviver);
        top2 = findViewById(R.id.top2surviver);
        top3 = findViewById(R.id.top3surviver);

            db.collection("DatanFire")
                    .document("38GY3Y4lIxxb4115mb41").get()
                    .addOnSuccessListener(documentSnapshot -> {
                                if (documentSnapshot.exists()) {
                                    DataClasses data = documentSnapshot.toObject(DataClasses.class);
                                    top1.setText(data.getTopname1());
                                    top2.setText(data.getTopname2());
                                    top3.setText(data.getTopname3());


                                    Datan.topteam1name = data.getTopname1();
                                    Datan.topteam2name = data.getTopname2();
                                    Datan.topteam3name = data.getTopname3();

                                    Datan.topteam1scr = data.getTopscr1();
                                    Datan.topteam2scr = data.getTopscr2();
                                    Datan.topteam3scr = data.getTopscr3();
                                }


                            });
        Datan.teamcom1 = "";
        Datan.teamcom2 = "";
        Datan.teamsurv = "";
        Datan.raund = 0;
        Datan.teamcomscore1 = 0;
        Datan.teamcomscore2 = 0;
        Datan.teamsurvscore = 0;
        Datan.teamraundscore = 4;
        Datan.team1 = true;
        Datan.team1win = false;
        Datan.team2win = false;
    }
    public void MainSurvivalBtn(View v){
       Intent intent = new Intent(this, SurvivalregisterActivity.class);
       startActivity(intent);
    }
    public void MainCommonBtn(View v){
        Intent intent = new Intent(this, Commonregister.class);
        startActivity(intent);
    }
}