package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class RandomiserActivity extends AppCompatActivity {
    int end = (int) (4+(4*Math.random()));
    Button name;
    boolean cont = false;
    Button resultat;
    Button random;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_randomiser);
        name = findViewById(R.id.name);
        resultat = findViewById(R.id.result);
        random = findViewById(R.id.continue1);
        random.setText("Randomise");
        if(Datan.common) {
            if (Datan.team1){
                name.setText("Team " + Datan.teamcom1);
            }else{
                name.setText("Team " + Datan.teamcom2);
            }
        }else{
            name.setText("Team " + Datan.teamsurv);
        }
    }
    public void CommonRandomise(View v) {
        final ImageView image = findViewById(R.id.image);
        if (cont) {
            Intent intent = new Intent(RandomiserActivity.this, MainCommonActivity.class);
            if(Datan.common) {
                if (Datan.team1){
                    Datan.raund++;
                }
            }else{
                Datan.raund++;
            }
            startActivity(intent);
        }else{
            Handler handler = new Handler();
            final Runnable runnable1 = new Runnable() {
                int count = 0;

                @Override
                public void run() {
                    if (count < end) {
                        image.setBackground(ContextCompat.getDrawable(getApplicationContext(), Datan.image[(int) count % Datan.image.length]));
                        count++;
                        handler.postDelayed(this, 300);
                    } else {
                        cont = true;
                        Datan.result = ((int) count-1) % Datan.game.length;
                        resultat.setText(Datan.game[Datan.result]);
                        random.setText("Continue");
                    }
                }
            };
            handler.postDelayed(runnable1, 0);
        }
    }

    public void EndGame(View view) {
        if(!Datan.common) {
            if(Datan.raund >= 8) {
                if (Datan.raund > Datan.topteam1scr) {
                    Datan.topteam1scr = Datan.raund;
                    Datan.topteam1name = Datan.teamsurv;
                } else if (Datan.raund > Datan.topteam2scr) {
                    Datan.topteam2scr = Datan.raund;
                    Datan.topteam2name = Datan.teamsurv;
                } else if (Datan.raund > Datan.topteam3scr) {
                    Datan.topteam3scr = Datan.raund;
                    Datan.topteam3name = Datan.teamsurv;
                }
            }
        }
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}


