package com.example.myapplication;

import com.google.firebase.firestore.FirebaseFirestore;

public class Datan {

   public static FirebaseFirestore db = FirebaseFirestore.getInstance();

   public static String WordAlias[] = {
           "somethingA1", "somethingA2", "somethingA3", "somethingA4", "somethingA5",
           "somethingA6", "somethingA7", "somethingA8", "somethingA9", "somethingA10",
           "somethingA11", "somethingA12", "somethingA13", "somethingA14", "somethingA15",
   };
   public static String WordsailA[] = {
           "somethings1", "somethings2", "somethings3", "somethings4", "somethings5",
           "somethings6", "somethings7", "somethings8", "somethings9", "somethings10",
           "somethings11", "somethings12", "somethings13", "somethings14", "somethings15",
   };
   public static String WordYes[] = {
           "somethingY1", "somethingY2", "somethingY3", "somethingY4", "somethingY5",
           "somethingY6", "somethingY7", "somethingY8", "somethingY9", "somethingY10",
           "somethingY11", "somethingY12", "somethingY13", "somethingY14", "somethingY15",
   };
   public static String WordNO[] = {
           "somethingN1", "somethingN2", "somethingN3", "somethingN4", "somethingN5",
           "somethingN6", "somethingN7", "somethingN8", "somethingN9", "somethingN10",
           "somethingN11", "somethingN12", "somethingN13", "somethingN14", "somethingN15",
   };
   public static int image[] = {
           R.drawable.alias,
           R.drawable.saila,
           R.drawable.yes,
           R.drawable.nonoise
   };
   public static String game[] = {
           "Alias",
           "sailA",
           "Yes/No",
           "NoNoise"
   };
   public static String teamcom1 = "";
   public static String teamcom2 = "";
   public static String teamsurv = "";
   public static int raund = 0;
   public static int result;
   public static int Scoreend;
   public static int teamcomscore1 = 0;
   public static int teamcomscore2 = 0;
   public static int teamsurvscore = 0;
   public static int teamraundscore = 4;
   public static boolean common = false;
   public static boolean team1 = true;
   public static boolean team1win = false;
   public static boolean team2win = false;


   public static String topteam1name;
   public static String topteam2name;
   public static String topteam3name;
   public static int topteam1scr;
   public static int topteam2scr;
   public static int topteam3scr;

   public static void setTopteam1scr(int topteam1scr) {
      Datan.topteam1scr = topteam1scr;
      db.collection("DatanFire").document("38GY3Y4lIxxb4115mb41").update("topscr1",topteam1scr);
   }

   public static void setTopteam2scr(int topteam2scr) {
      Datan.topteam2scr = topteam2scr;
      db.collection("DatanFire").document("38GY3Y4lIxxb4115mb41").update("topscr2",topteam2scr);

   }

   public static void setTopteam3scr(int topteam3scr) {
      Datan.topteam3scr = topteam3scr;
      db.collection("DatanFire").document("38GY3Y4lIxxb4115mb41").update("topscr3",topteam3scr);

   }

   public static void setTopteam1name(String topteam1name) {
      Datan.topteam1name = topteam1name;
      db.collection("DatanFire").document("38GY3Y4lIxxb4115mb41").update("topname1",topteam1name);

   }

   public static void setTopteam2name(String topteam2name) {
      Datan.topteam2name = topteam2name;
      db.collection("DatanFire").document("38GY3Y4lIxxb4115mb41").update("topname2",topteam2name);
   }

   public static void setTopteam3name(String topteam3name) {
      Datan.topteam3name = topteam3name;
      db.collection("DatanFire").document("38GY3Y4lIxxb4115mb41").update("topname3",topteam3name);
   }
}
