package com.example.myapplication.dataclasses;

public class DataClasses {
    private String topname1;
    private String topname2;
    private String topname3;
    private int topscr1;
    private int topscr2;
    private int topscr3;

    public DataClasses(String topname1, String topname2, String topname3, int topscr1, int topscr2, int topscr3) {
        this.topname1 = topname1;
        this.topname2 = topname2;
        this.topname3 = topname3;
        this.topscr1 = topscr1;
        this.topscr2 = topscr2;
        this.topscr3 = topscr3;
    }

    public DataClasses(){}

    public String getTopname1() {
        return topname1;
    }

    public void setTopname1(String topname1) {
        this.topname1 = topname1;
    }

    public String getTopname2() {
        return topname2;
    }

    public void setTopname2(String topname2) {
        this.topname2 = topname2;
    }

    public String getTopname3() {
        return topname3;
    }

    public void setTopname3(String topname3) {
        this.topname3 = topname3;
    }

    public int getTopscr1() {
        return topscr1;
    }

    public void setTopscr1(int topscr1) {
        this.topscr1 = topscr1;
    }

    public int getTopscr2() {
        return topscr2;
    }

    public void setTopscr2(int topscr2) {
        this.topscr2 = topscr2;
    }

    public int getTopscr3() {
        return topscr3;
    }

    public void setTopscr3(int topscr3) {
        this.topscr3 = topscr3;
    }
}
