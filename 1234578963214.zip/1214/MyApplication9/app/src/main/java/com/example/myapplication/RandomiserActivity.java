package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class RandomiserActivity extends AppCompatActivity {
    double end = 3+(4*Math.random());

    Button name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_randomiser);
        name = findViewById(R.id.name);
        if(Datan.common) {
            if (Datan.team1){
                Datan.raund++;
                name.setText("Team " + Datan.teamcom1);
            }else{
                name.setText("Team " + Datan.teamcom2);
            }
        }else{
            name.setText("Team " + Datan.teamsurv);
            Datan.raund++;
        }
    }
    public void CommonRandomise(View v) {
        ImageView image = findViewById(R.id.image);
        if(Datan.common) {
            if (Datan.team1){
            Datan.raund++;
            }else{
            }
        }else{
            Datan.raund++;
        }
        Handler handler = new Handler();
        Runnable runnable1 = new Runnable() {public void run() {}};
        for (double i = 0; i<end; i++){
            image.setBackground(ContextCompat.getDrawable(getApplicationContext(), Datan.image[(int) i % Datan.image.length]));
            handler.postDelayed(runnable1, 300);
        }
        handler.postDelayed(runnable1, 4000);
        Intent intent = new Intent(this, MainCommonActivity.class);
        startActivity(intent);
    }
}