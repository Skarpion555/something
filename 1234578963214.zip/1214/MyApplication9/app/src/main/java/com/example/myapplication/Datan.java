package com.example.myapplication;

public class Datan {

   public static String WordEng[] = {
           "something1", "something2", "something3", "something4", "something5",
           "something6", "something7", "something8", "something9", "something10",
           "something11", "something12", "something13", "something14", "something15",
   };
   public static int image[] = {
           R.drawable.some1,
           R.drawable.some2,
           R.drawable.some3,
           R.drawable.some4
   };
   public static String teamcom1 = "";
   public static String teamcom2 = "";
   public static String teamsurv = "";
   public static int raund = 0;
   public static int Scoreend;
   public static int teamcomscore1 = 0;
   public static int teamcomscore2 = 0;
   public static int teamsurvscore = 0;
   public static boolean common = false;
   public static boolean team1 = true;
   public static boolean team1win = false;
   public static boolean team2win = false;


}
