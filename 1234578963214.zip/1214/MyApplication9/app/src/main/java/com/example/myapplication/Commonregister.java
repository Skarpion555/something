package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class Commonregister extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_commonregister);
    }

    public void CommonregistercanselBtn(View v){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
    public void CommonregisterloginBtn(View v){
        EditText edit_text1 = (EditText)findViewById(R.id.editText1);
        EditText edit_text2 = (EditText)findViewById(R.id.editText2);
        EditText edit_text3 = (EditText)findViewById(R.id.editText3);
        String edittext1 = edit_text1.getText().toString();
        Datan.teamcom1 = edit_text1.getText().toString();
        String edittext2 = edit_text2.getText().toString();
        Datan.teamcom2 = edit_text2.getText().toString();
        String edittext3 = edit_text3.getText().toString();

        if(!edittext3.isEmpty()){
                try {
                    Integer.parseInt(edittext3);
                    Datan.Scoreend = Integer.parseInt(edit_text3.getText().toString());
                }
                catch (Exception e){
                    edit_text3.setHintTextColor(getResources().getColor(R.color.red));
                    edit_text3.setHint("Score need to be an intager");
                    edit_text3.setText("");
                }
        }else {
            Datan.Scoreend = 25;
        }

        if(!edittext1.isEmpty() && !edittext2.isEmpty()) {
            if (edittext1.equals(edittext2)) {
                edit_text1.setHintTextColor(getResources().getColor(R.color.red));
                edit_text2.setHintTextColor(getResources().getColor(R.color.red));
                edit_text1.setHint("Team name's need to be different");
                edit_text2.setHint("Team name's need to be different");
                edit_text1.setText("");
                edit_text2.setText("");
            }else {
                Intent intent = new Intent(this, CommonScoreActivity.class);
                startActivity(intent);
            }
        }else{
            edit_text1.setHintTextColor(getResources().getColor(R.color.red));
            edit_text2.setHintTextColor(getResources().getColor(R.color.red));
        }
    }
}